package com.polites.android.example;

import android.app.Activity;
import android.os.Bundle;

public class StandardImageXML extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	super.onCreate(savedInstanceState);
    	setContentView(R.layout.standard_image);
    }
}