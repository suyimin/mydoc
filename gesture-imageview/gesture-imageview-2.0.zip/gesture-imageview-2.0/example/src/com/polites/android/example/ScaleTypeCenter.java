package com.polites.android.example;

import android.app.Activity;
import android.os.Bundle;

public class ScaleTypeCenter extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	super.onCreate(savedInstanceState);
    	setContentView(R.layout.scale_type_center);
    }
}