package com.polites.android.example;

import android.os.Bundle;

public class ScaleTypeCenterInsideSmall extends ExampleActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	super.onCreate(savedInstanceState);
    	setContentView(R.layout.scale_type_inside_small);
    }
}