package com.alibaba.fastjson.asm;

import com.alibaba.fastjson.JSONException;

public class ASMException extends JSONException {

	private static final long serialVersionUID = 1L;

    public ASMException(String message){
        super(message);
    }
}
