package com.alibaba.json.bvt.bug;

import junit.framework.TestCase;


public class Issue109 extends TestCase {
    public void test_for_issue() throws Exception {
    }
}
