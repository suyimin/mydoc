package com.alibaba.json.bvt;

import junit.framework.TestCase;

import com.alibaba.fastjson.parser.JavaBeanMapping;

@SuppressWarnings("deprecation")
public class JavaBeanMappingTest extends TestCase {
	
	public void test_0 () throws Exception {
		JavaBeanMapping.getGlobalInstance();
	}
}
