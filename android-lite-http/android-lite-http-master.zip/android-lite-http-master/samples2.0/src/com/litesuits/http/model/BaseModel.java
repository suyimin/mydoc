package com.litesuits.http.model;

import java.io.Serializable;

/**
 * base model
 */
public abstract class BaseModel implements Serializable {}