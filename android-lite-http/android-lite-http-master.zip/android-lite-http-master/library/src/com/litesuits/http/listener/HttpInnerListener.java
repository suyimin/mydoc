package com.litesuits.http.listener;

public interface HttpInnerListener extends HttpExecuteListener, HttpConnectListener, HttpReadListener {
}