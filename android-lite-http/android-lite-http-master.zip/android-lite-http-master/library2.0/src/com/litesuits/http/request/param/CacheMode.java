package com.litesuits.http.request.param;

/**
 * @author MaTianyu
 * @date 2015-04-22
 */
public enum CacheMode {
    NetOnly,
    NetFirst,
    CacheFirst,
    CacheOnly
}
