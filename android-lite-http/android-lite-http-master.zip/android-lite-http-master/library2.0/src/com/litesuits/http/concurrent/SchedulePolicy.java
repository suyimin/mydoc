package com.litesuits.http.concurrent;

/**
 * @author MaTianyu
 * @date 2015-04-23
 */
public enum SchedulePolicy {
    LastInFirstRun,
    FirstInFistRun
}
