package com.bumptech.glide.load.engine.bitmap_recycle;

interface Poolable {
  void offer();
}
