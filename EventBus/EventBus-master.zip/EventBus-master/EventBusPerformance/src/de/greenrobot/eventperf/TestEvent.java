package de.greenrobot.eventperf;

/** Used by otto and EventBus */
public class TestEvent {

}
