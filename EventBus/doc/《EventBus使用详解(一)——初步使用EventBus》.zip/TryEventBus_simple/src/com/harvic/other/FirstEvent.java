package com.harvic.other;

public class FirstEvent {

	private String mMsg;
	public FirstEvent(String msg) {
		// TODO Auto-generated constructor stub
		mMsg = msg;
	}
	public String getMsg(){
		return mMsg;
	}
}
