package com.cainwong.demo.events;

/**
 * Created by cwong on 1/27/15.
 */
public class LayoutEvent {

    public final boolean isTwoPane;

    public LayoutEvent(boolean isTwoPane) {
        this.isTwoPane = isTwoPane;
    }

}
