package com.cainwong.demo.events;

/**
 * Created by cwong on 1/27/15.
 */
public class ItemSelectedEvent {

    public final int position;

    public ItemSelectedEvent(int position) {
        this.position = position;
    }

}
