# EventBus-Config-Demo

Demostrates the use of [Green Robot's Event Bus](https://github.com/greenrobot/EventBus) "sticky events" to handle configuration changes.
