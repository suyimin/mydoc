/** Automatically generated file. DO NOT MODIFY */
package com.example.swiperefreshloadlistview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}