package com.daimajia.swipe.interfaces;

public interface SwipeAdapterInterface {
    public int getSwipeLayoutResourceId(int position);
}
