SwipeRefreshLoadListview
========================
This project is implemented with a refresh, load, sliding delete function Demo by using XListview and AndroidSwipeLayout. 
More exciting content, please pay attention to my blog http://blog.csdn.net/zhaokaiqiang1992

这个项目是利用XListview和AndroidSwipeLayout实现了一个带有刷新、加载、滑动删除功能的小Demo。
更多精彩内容，请关注我的技术博客 http://blog.csdn.net/zhaokaiqiang1992
