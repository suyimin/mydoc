#警告

本项目触摸机制复杂，BUG满天飞，极难维护，根据每个人的业务需求修改起来异常繁琐，所以非常不推荐在生产环境使用，当然，你可以看看实现原理，然后改成自己想要的结果。所以在使用本项目时出现的问题，我很难帮你解决，推荐你使用其他方案。

早期项目，必有疏漏，还请原谅。

# ZListVIew
整合了刷新、加载更多、滑动删除功能的ZListview，更多信息请关注：[http://blog.csdn.net/zhaokaiqiang1992](http://blog.csdn.net/zhaokaiqiang1992)

#About Me
![header](http://avatar.csdn.net/C/6/8/1_bz419927089.jpg)
</br>

```
    Hi,clever programmer！I feel very honored that you are interested in my project!
    I'm a college student and majoring in Information Engineering in Qingdao University 
of Science & Technology.
    I already have one year work experience,although not yet graduated.I really enjoy 
coding,and love to share experience with others.Open source project is my favourite!
    If you want to know more about me,you can see my CSDN blog by click the following website!
```
###[Click Hear](http://blog.csdn.net/zhaokaiqiang1992)