/*
 * Copyright (c) 2014, 青岛司通科技有限公司 All rights reserved.
 * File Name：OnLayout.java
 * Version：V1.0
 * Author：zhaokaiqiang
 * Date：2015-1-6
 */

package com.socks.zlistview.listener;

import com.socks.zlistview.widget.ZSwipeItem;

public interface OnSwipeLayoutListener {
	public void onLayout(ZSwipeItem v);
}
