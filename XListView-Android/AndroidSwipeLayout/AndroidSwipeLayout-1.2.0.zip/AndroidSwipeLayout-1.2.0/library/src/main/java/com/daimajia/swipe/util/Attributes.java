package com.daimajia.swipe.util;


public class Attributes {

    public enum Mode {
        Single, Multiple
    }
}
