/** Automatically generated file. DO NOT MODIFY */
package cn.wei.flowingflying.propreferences;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}