package com.test;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class TestActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	System.out.println("taskId:"+getTaskId()+"\tisTaskRoot:"+isTaskRoot());
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        Button start = (Button)findViewById(R.id.start);
        start.setOnClickListener(new StartOnclickListener());
    }
    
    class StartOnclickListener implements OnClickListener {
    	@Override
    	public void onClick(View v){
    		Intent intent = new Intent("com.xiaoqlu.test");
    		startActivity(intent);
    	}
    }
}