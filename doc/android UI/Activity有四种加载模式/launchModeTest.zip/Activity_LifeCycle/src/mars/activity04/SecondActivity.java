package mars.activity04;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class SecondActivity extends Activity {
	public static int count = 0;
	public int tag = 0;
	public SecondActivity(){
		tag=++count;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		System.out.println("\nSecondActivity taskId:"+getTaskId());
		System.out.println("SecondActivity"+tag+"--->onCreate");
		super.onCreate(savedInstanceState);
		setContentView(R.layout.second);
		Button backToFirst = (Button)findViewById(R.id.backToFirst);
		backToFirst.setOnClickListener(new startFirstListener());
		Button startThird = (Button)findViewById(R.id.startThird);
		startThird.setOnClickListener(new StartThirdListener());
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		System.out.println("SecondActivity"+tag+"--->onDestory");
		super.onDestroy();
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		System.out.println("SecondActivity"+tag+"--->onPause");
		super.onPause();
	}

	@Override
	protected void onRestart() {
		// TODO Auto-generated method stub
		System.out.println("SecondActivity"+tag+"--->onRestart");
		super.onRestart();
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		System.out.println("SecondActivity"+tag+"--->onResume"+"\tisTaskRoot:"+isTaskRoot());
		super.onResume();
	}

	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		System.out.println("SecondActivity"+tag+"--->onStart");
		super.onStart();
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		System.out.println("SecondActivity"+tag+"--->onStop");
		super.onStop();
	}
	
/*
	@Override
	protected void onRestoreInstanceState(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onRestoreInstanceState(savedInstanceState);
		System.out.println("SecondActivity"+tag+" --->onRestoreInstanceState");
	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		// TODO Auto-generated method stub
		super.onSaveInstanceState(outState);
		System.out.println("SecondActivity"+tag+" --->onSaveInstanceState");
	}*/
	
	
	@Override
	protected void onNewIntent(Intent intent) {
		// TODO Auto-generated method stub
		super.onNewIntent(intent);
		System.out.println("SecondActivity"+tag+"--->onNewIntent");
	}

	class startFirstListener implements OnClickListener{
		@Override
		public void onClick(View v){
			Intent intent = new Intent();
			intent.setClass(SecondActivity.this, FirstActivity.class);
			startActivity(intent);
		}
	}
	class StartThirdListener implements OnClickListener{
		@Override
		public void onClick(View v){
			Intent intent = new Intent();
			intent.setClass(SecondActivity.this, ThirdActivity.class);
			startActivity(intent);
		}
	}
	
}
