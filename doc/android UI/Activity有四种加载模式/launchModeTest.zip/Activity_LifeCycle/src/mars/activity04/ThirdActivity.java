package mars.activity04;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class ThirdActivity extends Activity {
	public static int count = 0;
	public int tag = 0;
	public ThirdActivity(){
		tag=++count;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		System.out.println("\nThirdActivity taskId:"+getTaskId());
		System.out.println("ThirdActivity"+tag+"--->onCreate");
		super.onCreate(savedInstanceState);
		setContentView(R.layout.third);
		Button startFirst = (Button)findViewById(R.id.startFirst);
		startFirst.setOnClickListener(new StartFirstListener());
		
		Button startSecond = (Button)findViewById(R.id.startSecond);
		startSecond.setOnClickListener(new StartSecondListener());
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		System.out.println("ThirdActivity"+tag+"--->onDestory");
		super.onDestroy();
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		System.out.println("ThirdActivity"+tag+"--->onPause");
		super.onPause();
	}

	@Override
	protected void onRestart() {
		// TODO Auto-generated method stub
		System.out.println("ThirdActivity"+tag+"--->onRestart");
		super.onRestart();
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		System.out.println("ThirdActivity"+tag+"--->onResume"+"\tisTaskRoot:"+isTaskRoot());
		super.onResume();
	}

	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		System.out.println("ThirdActivity"+tag+"--->onStart");
		super.onStart();
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		System.out.println("ThirdActivity"+tag+"--->onStop");
		super.onStop();
	}
	
/*
	@Override
	protected void onRestoreInstanceState(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onRestoreInstanceState(savedInstanceState);
		System.out.println("ThirdActivity"+tag+" --->onRestoreInstanceState");
	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		// TODO Auto-generated method stub
		super.onSaveInstanceState(outState);
		System.out.println("ThirdActivity"+tag+" --->onSaveInstanceState");
	}*/
	
	
	@Override
	protected void onNewIntent(Intent intent) {
		// TODO Auto-generated method stub
		super.onNewIntent(intent);
		System.out.println("ThirdActivity"+tag+"--->onNewIntent");
	}

	class StartFirstListener implements OnClickListener{
		@Override
		public void onClick(View v){
			Intent intent = new Intent();
			intent.setClass(ThirdActivity.this, FirstActivity.class);
			startActivity(intent);
		}
	}
	class StartSecondListener implements OnClickListener{
		@Override
		public void onClick(View v){
			Intent intent = new Intent();
			intent.setClass(ThirdActivity.this, SecondActivity.class);
			startActivity(intent);
		}
	}
	
}
