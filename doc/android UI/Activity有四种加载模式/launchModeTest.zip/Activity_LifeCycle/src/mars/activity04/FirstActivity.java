package mars.activity04;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class FirstActivity extends Activity {
	public static int count = 0;
	public int tag = 0;
    /** Called when the activity is first created. */
	private Button myButton;
	public FirstActivity(){
		++count;
		tag = count;
	}
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	System.out.println("\nFirstAcvity taskId:"+getTaskId());
    	System.out.println("FirstAcvity"+tag+" --->onCreate");
    	if(savedInstanceState != null){
    		if(savedInstanceState.getString("key")!=null)
    			System.out.println("onCreatekey-->"+savedInstanceState.getString("key"));
    		if(savedInstanceState.getString("key1")!=null)
    			System.out.println("onCreatekey-->"+savedInstanceState.getString("key1"));
    	}
    	super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        myButton = (Button)findViewById(R.id.myButton);
        myButton.setText("�����ڶ���Activity");
        myButton.setOnClickListener(new ButtonOnClickListener());
    }

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
    	System.out.println("FirstAcvity"+tag+" --->onDestory");
		super.onDestroy();
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
    	System.out.println("FirstAcvity"+tag+" --->onPause");
		super.onPause();
	}

	@Override
	protected void onRestart() {
		// TODO Auto-generated method stub
    	System.out.println("FirstAcvity"+tag+" --->onRestart");
		super.onRestart();
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
    	System.out.println("FirstAcvity"+tag+" --->onResume"+"\tisTaskRoot:"+isTaskRoot());
		super.onResume();
	}

	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
    	System.out.println("FirstAcvity"+tag+" --->onStart");
		super.onStart();
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
    	System.out.println("FirstAcvity"+tag+" --->onStop");
		super.onStop();
	}
	/*
	@Override
	protected void onRestoreInstanceState(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		savedInstanceState.putString("key1", "test1");
		super.onRestoreInstanceState(savedInstanceState);
		System.out.println("FirstAcvity"+tag+" --->onRestoreInstanceState");
		System.out.println("onRestoreInstanceStatekey-->"+savedInstanceState.getString("key"));
	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		// TODO Auto-generated method stub
		outState.putString("key", "test");
		super.onSaveInstanceState(outState);
		System.out.println("FirstAcvity"+tag+" --->onSaveInstanceState");
	}
*/
	@Override
	protected void onNewIntent(Intent intent) {
		// TODO Auto-generated method stub
		super.onNewIntent(intent);
		System.out.println("FirstAcvity"+tag+"--->onNewIntent");
	}
	
	
	class ButtonOnClickListener implements OnClickListener{

		@Override
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(FirstActivity.this,SecondActivity.class);
			FirstActivity.this.startActivity(intent);
		}
		
	}
	
}