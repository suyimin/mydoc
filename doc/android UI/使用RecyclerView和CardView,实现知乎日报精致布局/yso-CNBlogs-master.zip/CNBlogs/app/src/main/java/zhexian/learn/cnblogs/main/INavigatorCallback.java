package zhexian.learn.cnblogs.main;

/**
 * Created by Administrator on 2015/8/28.
 */
public interface INavigatorCallback {
    void OpenNavigator();

    void CloseNavigator();

    void OnClickNews();

    void OnClickBlog();
}

