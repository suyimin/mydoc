package zhexian.learn.cnblogs.base;

/**
 * Created by 陈俊杰 on 2015/8/28.
 * 数据父类
 */
public class BaseEntity {
    private int entityType;

    public int getEntityType() {
        return entityType;
    }

    public void setEntityType(int entityType) {
        this.entityType = entityType;
    }
}
