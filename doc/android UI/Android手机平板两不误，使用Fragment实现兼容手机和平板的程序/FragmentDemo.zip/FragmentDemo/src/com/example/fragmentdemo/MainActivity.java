package com.example.fragmentdemo;

import android.app.Activity;
import android.os.Bundle;

/**
 * 程序的主界面。
 * 
 * @author guolin
 */
public class MainActivity extends Activity {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

}
