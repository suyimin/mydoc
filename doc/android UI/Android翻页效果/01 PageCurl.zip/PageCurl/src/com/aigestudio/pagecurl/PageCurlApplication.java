package com.aigestudio.pagecurl;

import android.app.Application;

/**
 * Ӧ��Application��
 * 
 * @author AigeStudio
 * @since 2014/12/15
 * @version 1.0.0
 * 
 */
public class PageCurlApplication extends Application {

}
