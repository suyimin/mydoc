package com.aigestudio.customviewdemo.bo;

/**
 * ҵ���߼���ӿ�
 * 
 * @author Aige
 * @since 2014/11/19
 * 
 */
public interface IBO {

}
