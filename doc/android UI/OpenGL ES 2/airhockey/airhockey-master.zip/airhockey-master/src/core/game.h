void on_surface_created();
void on_surface_changed(int width, int height);
void on_draw_frame();
void on_touch_press(float normalized_x, float normalized_y);
void on_touch_drag(float normalized_x, float normalized_y);
