void on_surface_created();
void on_surface_changed();
void on_draw_frame();
