package com.example.customanimationforactivity;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;

public class AppActivity extends Activity
{

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.xx);
		
	}

}
