/** Automatically generated file. DO NOT MODIFY */
package com.android.volley;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}