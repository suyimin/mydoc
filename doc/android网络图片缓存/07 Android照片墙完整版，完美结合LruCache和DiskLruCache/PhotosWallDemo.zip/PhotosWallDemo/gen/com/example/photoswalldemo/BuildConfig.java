/** Automatically generated file. DO NOT MODIFY */
package com.example.photoswalldemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}