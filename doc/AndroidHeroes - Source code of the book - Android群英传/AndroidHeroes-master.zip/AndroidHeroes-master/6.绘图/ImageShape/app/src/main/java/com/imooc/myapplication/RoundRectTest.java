package com.imooc.myapplication;

import android.app.Activity;
import android.os.Bundle;

public class RoundRectTest extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.round_rect);
    }
}
