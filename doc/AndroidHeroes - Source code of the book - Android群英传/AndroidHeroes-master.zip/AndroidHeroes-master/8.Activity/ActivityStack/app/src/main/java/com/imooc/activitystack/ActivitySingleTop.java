package com.imooc.activitystack;

import android.app.Activity;
import android.os.Bundle;


public class ActivitySingleTop extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_singletop);
    }
}
