package com.wt.HomeSelector;

public class EvtMsgCode {
	public static final int SWITCH = 10;
	public static final int HOMEINFO = 11;
	public static final int UNINSTALL = 12;
	public static final int DELETE = 20; 
	public static final int CLEARDEFAULT = 30;
	public static final int SETDEFAULT = 31;
}
