package com.seven.servicetestdemo;

public interface ICountService {
	public int getCurrentLoad();
}
