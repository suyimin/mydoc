http://blog.csdn.net/yihongyuelan/article/details/7216188 这是文章源地址
总共有5个包，分别使用了广播，共享文件，自定义接口，信使以及AIDL与Service进行交互。如有疑问请参考文章并留言，我将及时回复。谢谢 
