package com.feixun.hu.ipc.client;

import android.app.Activity;
import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class IpcClient extends Activity 
{
	
	private IMyService mIMyService;
	
	private Button setName, getName;
	private TextView show;
	private EditText input;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        //获取各组件
        setName = (Button)findViewById(R.id.set);
        getName = (Button)findViewById(R.id.get);
        show = (TextView)findViewById(R.id.show);
        input = (EditText)findViewById(R.id.input);
        
        //创建Intent，对应服务端注册的Intent
        Intent intent = new Intent();
        intent.setAction("com.feixun.hu.action.IPC_SERVICE");
        //绑定连接远程服务
        bindService(intent, conn, Service.BIND_AUTO_CREATE);
        
        //为设置按钮绑定监听
        setName.setOnClickListener(new OnClickListener() 
        {
			
			@Override
			public void onClick(View v) 
			{
				// TODO Auto-generated method stub
				if(input.getText() != null)
				{
					try 
					{
						//将输入的信息保存到远程服务端
						mIMyService.setName(input.getText().toString());
					} 
					catch (RemoteException e) 
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		});
        
        //获取按钮绑定监听
        getName.setOnClickListener(new OnClickListener() 
        {
			//String name = mIMyService.getName();
			@Override
			public void onClick(View v) 
			{
				// TODO Auto-generated method stub
				try {
					if(mIMyService.getName() != null)
					{
						show.setText(mIMyService.getName().toString());
					}
				} catch (RemoteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}	
			}
		});
    }
    
    //实现客户端与服务端绑定的关键部分
    private ServiceConnection conn = new ServiceConnection() 
    {
		//解除连接服务端
		@Override
		public void onServiceDisconnected(ComponentName name) 
		{
			// TODO Auto-generated method stub
			mIMyService = null;
		}
		//连接服务端
		@Override
		public void onServiceConnected(ComponentName name, IBinder service) 
		{
			// TODO Auto-generated method stub
			/*此处实现获取通过IpcService的onBind方法返回的mServiceBinder对象的代理。
			 * 参数service为绑定获得的远程服务IpcService的mServiceBinder对象，
			 * 而调用IMyService.Stub的函数asInterface获取的是mServiceBinder对象的代理。
			 */
			mIMyService = IMyService.Stub.asInterface(service);
		}
	};

	@Override
	protected void onDestroy() 
	{
		// TODO Auto-generated method stub
		super.onDestroy();
		//解除绑定
		unbindService(conn);
	}
}