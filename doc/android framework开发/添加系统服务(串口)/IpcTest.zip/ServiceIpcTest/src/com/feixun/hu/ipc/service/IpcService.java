package com.feixun.hu.ipc.service;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;
public class IpcService extends Service 
{
	//用于保存客户端输入的用户名
	private String userName;
	private ServiceBinder mServiceBinder;
	
	@Override
	public void onCreate() 
	{
		// TODO Auto-generated method stub
		super.onCreate();
		//创建ServiceBinder对象（Binder类型对象）
		mServiceBinder = new ServiceBinder();
	}

	/*定义一个继承IMyService接口内部类Stub的实现与客户端通信的Binder类型的类，
	 * IMyService.Stub是Binder类型
	 */
	public class ServiceBinder extends IMyService.Stub
	{

		@Override
		public String getName() throws RemoteException 
		{
			// TODO Auto-generated method stub
			return userName;
		}

		@Override
		public void setName(String name) throws RemoteException 
		{
			// TODO Auto-generated method stub
			userName = name;
		}
		
	}
	
	@Override
	public IBinder onBind(Intent arg0) 
	{
		// TODO Auto-generated method stub
		
		/*与客户端连接时，返回该Binder对象.
		 * 1.如果连接的客户端和该服务端属于同一个进程，则此处直接返回mServiceBinder本身
		 * 2.如果连接的客户端和该服务不属于同一个进程，则返回的是mServiceBinder对象的代理
		 */
		return mServiceBinder;
	}
}
