package com.infrastructure.activity;

import android.app.Activity;
import android.os.Bundle;

public abstract class BaseActivity extends Activity {

}