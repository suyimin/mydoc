package com.youngheart.activity.others;

import android.os.Bundle;

import com.youngheart.base.AppBaseActivity;

public class MainActivity extends AppBaseActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
	}
}
