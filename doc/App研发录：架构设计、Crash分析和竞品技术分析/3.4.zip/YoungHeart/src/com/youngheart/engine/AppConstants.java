package com.youngheart.engine;

public class AppConstants {
	public final static String Email = "Email";
	public final static String NeedCallback = "NeedCallback";

	public final static String CACHEDIR = "/data/data/com.youngheart/cache/";	
}
