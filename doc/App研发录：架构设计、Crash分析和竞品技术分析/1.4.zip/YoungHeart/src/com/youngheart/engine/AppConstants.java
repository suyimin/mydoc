package com.youngheart.engine;

public class AppConstants {
	public final static String Email = "Email";
	public final static String Cinema = "Cinema";
}
