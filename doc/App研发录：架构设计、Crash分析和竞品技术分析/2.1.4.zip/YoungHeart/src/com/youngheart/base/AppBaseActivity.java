package com.youngheart.base;

import com.infrastructure.activity.BaseActivity;

public abstract class AppBaseActivity extends BaseActivity {
}