package com.example.testcode;

public class IdCard {

	private String idCardDesc;
	private String idCardNumber;

	public String getIdCardNumber() {
		return idCardNumber;
	}

	public void setIdCardNumber(String idCardNumber) {
		this.idCardNumber = idCardNumber;
	}

	public String getIdCardDesc() {
		return idCardDesc;
	}

	public void setIdCardDesc(String idCardDesc) {
		this.idCardDesc = idCardDesc;
	}

}
