//
//  AboutUsViewController.h
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface BViewController : BaseViewController

@property (nonatomic, retain) NSString* version;

@end
