//
//  AboutUsViewController.h
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface AboutUsViewController : BaseViewController

@property (nonatomic, retain) NSString* nickName;

@end
