//
//  APageViewController.h
//  MyApp
//
//  Created by jax on 13-9-2.
//  Copyright (c) 2013年 Bao. All rights reserved.
//

#import "AppBaseViewController.h"

@interface APageViewController : AppBaseViewController

@end
