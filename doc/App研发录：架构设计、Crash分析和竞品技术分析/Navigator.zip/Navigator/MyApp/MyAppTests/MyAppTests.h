//
//  MyAppTests.h
//  MyAppTests
//
//  Created by jax on 13-9-6.
//  Copyright (c) 2013年 Bao. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface MyAppTests : SenTestCase

@end
