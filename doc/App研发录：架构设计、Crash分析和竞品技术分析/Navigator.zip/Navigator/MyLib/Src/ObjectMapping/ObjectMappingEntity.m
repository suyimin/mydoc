#import "ObjectMappingEntity.h"
#import "ObjectMapping.h"

@implementation ObjectMappingEntity

@synthesize from = _from;
@synthesize to = _to;
@synthesize typeOfClass = _typeOfClass;
@synthesize isSimpleType = _isSimpleType;

@end
