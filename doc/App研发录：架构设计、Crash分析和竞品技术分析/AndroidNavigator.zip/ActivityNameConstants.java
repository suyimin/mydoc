package com.example.navigator;

public class ActivityNameConstants {
	public final static String SecondActivity 
		= "com.example.navigator.SecondActivity";
}

