package com.example.switchenvbymenu;

public interface Config {
	public final static boolean isDebug = true;
}