package com.example.switchenvbymenu;

public class Globals {
	public static String IP = "http://212.1.2.3";
}