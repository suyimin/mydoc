package com.youngheart.engine;

import com.youngheart.entity.CinemaBean;

public class GlobalVariables {
	public static CinemaBean Cinema;
}
