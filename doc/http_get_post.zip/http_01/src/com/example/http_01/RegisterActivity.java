package com.example.http_01;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class RegisterActivity extends Activity {
	private EditText name;
	private EditText age;
	private Button register;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.register);
		name = (EditText) findViewById(R.id.edit_name);
		age = (EditText) findViewById(R.id.edit_age);
		register = (Button) findViewById(R.id.btn_register);
		register.setOnClickListener(new OnClickListener() {
			String url = "http://223.2.45.232:8080/web/MyServlet";//����д�Լ����Ե�IP
			@Override
			public void onClick(View v) {
				new HttpThread1(url, name.getText().toString(), age.getText().toString()).start();
				
			}
		});
	}

}
