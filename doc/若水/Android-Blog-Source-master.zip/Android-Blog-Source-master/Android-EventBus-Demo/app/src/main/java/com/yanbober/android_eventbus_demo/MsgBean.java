package com.yanbober.android_eventbus_demo;

/**
 * Author       : yanbo
 * Date         : 2015-05-12
 * Time         : 14:30
 * Description  :
 */
public class MsgBean {
    private String msg;

    public MsgBean(String msg) {
        this.msg = msg;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
