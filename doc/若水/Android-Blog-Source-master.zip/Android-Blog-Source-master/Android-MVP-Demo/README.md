# 我的博客实例库（http://blog.csdn.net/yanbober）

##说明

该实例是博客 [浅谈MVP实现Android应用层开发](http://blog.csdn.net/yanbober/article/details/45645115) 的讲解实例Demo。
