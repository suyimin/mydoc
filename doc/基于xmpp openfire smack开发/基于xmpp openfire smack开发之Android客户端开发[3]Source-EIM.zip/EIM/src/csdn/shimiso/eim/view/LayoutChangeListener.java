package csdn.shimiso.eim.view;

public interface LayoutChangeListener {
	public void doChange(int lastIndex, int currentIndex);
}
