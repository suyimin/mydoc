package com.aptl.services;

/**
 * @author Erik Hellman
 */
public class MyComplexResult {
}
