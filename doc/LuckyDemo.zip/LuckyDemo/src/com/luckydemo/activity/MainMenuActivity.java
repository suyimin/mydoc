package com.luckydemo.activity;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener2;
import com.handmark.pulltorefresh.library.PullToRefreshListView;
import com.luckydemo.R;
import com.luckydemo.adapter.MainMenuAdapter;
import com.luckydemo.entity.MainMenuItem;

public class MainMenuActivity extends Activity implements OnItemClickListener,
        OnScrollListener, OnRefreshListener2<ListView> {

    PullToRefreshListView pullToRefreshView;
    ArrayList<MainMenuItem> itemList;
    MainMenuAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);
        pullToRefreshView = (PullToRefreshListView) findViewById(R.id.pull_to_refresh_listview);
        pullToRefreshView.setOnItemClickListener(this);
        pullToRefreshView.setOnScrollListener(this);
        pullToRefreshView.setOnRefreshListener(this);
        loadData();
        adapter = new MainMenuAdapter(MainMenuActivity.this, itemList);
        pullToRefreshView.setAdapter(adapter);
    }

    void loadData() {
        itemList = new ArrayList<MainMenuItem>();
        MainMenuItem clipImage = new MainMenuItem();
        clipImage.setName("图片剪切");
        clipImage.setInstruction("技术还是挺简单的。");
        itemList.add(clipImage);
        MainMenuItem handlerPost1 = new MainMenuItem();
        handlerPost1.setName("handler-post-1");
        handlerPost1.setInstruction("技术还是挺简单的。");
        itemList.add(handlerPost1);
        MainMenuItem handlerPost2 = new MainMenuItem();
        handlerPost2.setName("handler-post-2");
        handlerPost2.setInstruction("技术还是挺简单的。");
        itemList.add(handlerPost2);
        MainMenuItem okhttp = new MainMenuItem();
        okhttp.setName("okhttp https");
        okhttp.setInstruction("技术还是挺简单的。");
        itemList.add(okhttp);
        
        
        
        
    }

    @Override
    public void onScroll(AbsListView arg0, int arg1, int arg2, int arg3) {

    }

    @Override
    public void onScrollStateChanged(AbsListView arg0, int arg1) {

    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position,
            long id) {
        switch (position) {
        case 1:
            Intent itent1 = new Intent(MainMenuActivity.this,
                    ClipImageActivity.class);
            startActivity(itent1);
            break;
        case 2:
            Intent itent2 = new Intent(MainMenuActivity.this,
                    HandlerPost1Activity.class);
            startActivity(itent2);
            break;
        case 3:
            Intent itent3 = new Intent(MainMenuActivity.this,
                    HandlerPost2Activity.class);
            startActivity(itent3);
            break;
        case 4:
            Intent itent4 = new Intent(MainMenuActivity.this,
                    OkhttpActivity.class);
            startActivity(itent4);
            break;
        default:
            break;
        }
    }

    @Override
    public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
        pullToRefreshView.onRefreshComplete();
    }

    @Override
    public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
        pullToRefreshView.onRefreshComplete();
    }
}
