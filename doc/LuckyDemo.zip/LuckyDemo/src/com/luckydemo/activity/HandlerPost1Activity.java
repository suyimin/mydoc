package com.luckydemo.activity;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;

import com.luckydemo.R;

public class HandlerPost1Activity extends Activity {
    TextView valueTv;
    public Handler mHandler;
    private MyThread thread;
    // 定义一个自己的线程
    class MyThread extends Thread {
      @Override
      public void run() {
        System.out.println("线程开始运行");
        Runnable r = new Runnable() {
          @Override
          public void run() {
            valueTv.setTextColor(Color.RED);
            valueTv.setTextSize(30);
            valueTv.setText("从线程中传过来的代码段");
            System.out.println("执行runnable代码的线程："+Thread.currentThread().getName());
          }
        };
        //上面代码中的runnable线程体经过post后会直接传送到主线程中执行修改字体的操作。
        //post直接可以把一段代码当做变量一样传递，但是请不要传送耗时操作的代码到主线程中
        mHandler.post(r);
      }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
      setContentView(R.layout.activity_handler_post);
      valueTv = (TextView)findViewById(R.id.vale_textView);
      mHandler = new Handler();
      thread = new MyThread();
      // 启动线程
      thread.start();
    }
}
