package com.luckydemo.activity;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;

import com.luckydemo.R;

public class HandlerPost2Activity extends Activity {

    private Button btn = null;
    private Handler handler = new Handler();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        handler.post(r);
        setContentView(R.layout.activity_handler_post);
        btn = (Button) findViewById(R.id.hello);
        String s = (String) btn.getText();
        System.out.println(s);
        System.out.println("activity--->" + Thread.currentThread().getId());
        System.out.println("Activityname--->"
                + Thread.currentThread().getName());
    }

    Runnable r = new Runnable() {
        public void run() {
            System.out.println("handler--->" + Thread.currentThread().getId());
            System.out.println("handlername--->"
                    + Thread.currentThread().getName());
            try {
                Thread.sleep(10000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    };

}
//打印结果：
//Button
//activity--->1
//Activityname--->main
//handler--->1
//handlername--->main