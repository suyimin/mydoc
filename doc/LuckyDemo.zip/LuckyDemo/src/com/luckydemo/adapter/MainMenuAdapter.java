package com.luckydemo.adapter;

import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.luckydemo.R;
import com.luckydemo.activity.MainMenuActivity;
import com.luckydemo.entity.MainMenuItem;

public class MainMenuAdapter extends BaseAdapter {
    private final ArrayList<MainMenuItem> itemList;
    private final MainMenuActivity context;

    public MainMenuAdapter(MainMenuActivity context,
            ArrayList<MainMenuItem> itemList) {
        this.context = context;
        this.itemList = itemList;
    }

    public int getCount() {
        return itemList.size();
    }

    public MainMenuItem getItem(final int position) {
        return itemList.get(position);
    }

    public long getItemId(final int position) {

        return position;
    }

    @SuppressLint("InflateParams")
    @Override
    public View getView(final int position, View convertView,
            final ViewGroup parent) {
        final Holder holder;
        if (convertView == null) {
            holder = new Holder();
            convertView = context.getLayoutInflater().inflate(
                    R.layout.item_main_menu, null);
            holder.tvName = (TextView) convertView.findViewById(R.id.tv_name);
            holder.tvInstruction = (TextView) convertView
                    .findViewById(R.id.tv_instruction);
            convertView.setTag(holder);
        } else {
            holder = (Holder) convertView.getTag();
        }

        MainMenuItem item = itemList.get(position);
        holder.tvName.setText(item.getName());
        holder.tvInstruction.setText(item.getInstruction());
        return convertView;
    }

    class Holder {
        TextView tvName;
        TextView tvInstruction;
    }
}
